LockwoodSTEM Volume I Resource Library

Volume-I:
LS-REF-003 through LS-REF-008 manuscript starters

Assets:
Part001 Aircraft Mounting Bracket
Part002 Wing Rib
Part003 Bulkhead Plate
Part004 Avionics Equipment Bracket
Part005 Sensor Housing

Templates:
LS-TMP series

Next step: replace manuscript starters with fully laid-out publishing editions.
